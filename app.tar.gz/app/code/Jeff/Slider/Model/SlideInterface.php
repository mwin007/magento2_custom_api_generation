<?php
namespace Jeff\Slider\Model;

interface SlideInterface
{
// an empty interface
}
